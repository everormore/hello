# GitPitch - The Template

*THE FASTEST WAY FROM IDEA TO PRESENTATION*

For details, see the complete template documentation [here](https://gitpitch.com/docs/the-template).

